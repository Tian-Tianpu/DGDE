import numpy as np
import joblib
import os
import EGD, ESGD, NGDE, DGDE
import time


def run_hybrid_algorithms(objective_function, gradient_function, x_min, x_max, figure_save_path, dimension, learning_rate, budget,
                        population_size,  K_0, K_base, T_per, pho_high, pho_low, p_m,
                        F, fitness_p, niche_size, pop_strength, mutate_strength,
                        if_escape_fitness, gradient_thresh, mutate_thresh, mutate_turns,
                        gd_budget, evo_budget):
    """
    运行 AdaptiveGDE, NGDE, EGD, ESGD, DGDE  算法并保存结果。
    """

      # ------------------
    print("=====Running NGDE_model======")

    NGDE_model = NGDE.NGDE(population_size=population_size, dimension=dimension, niche_size=niche_size,
                        budget=budget, F=F, fitness_p=fitness_p, learning_rate=learning_rate)
    start_time = time.time()
    NGDE_model.NGDE(x_min, x_max, objective_function, gradient_function)
    end_time = time.time()
    NGDE_model.run_time = end_time - start_time

    with open(figure_save_path + 'NGDE_model.pkl', 'wb') as f:
        joblib.dump(NGDE_model, f)

    print(f"Best Fitness: {NGDE_model.g_best.target.fitness}")
    fitness_values = [agent.target.fitness for agent in NGDE_model.pop]
    print(f"Mean Fitness: {np.mean(fitness_values)}")
    print(f"Variance of Fitness: {np.var(fitness_values)}")

    # ------------------
    print("=====Running DGDE_model======")

    DGDE_model = DGDE.DGDE(population_size=population_size, dimension=dimension, niche_size=niche_size,
                           budget=budget, F=F, K_0=K_0, K_base=K_base, T_per=T_per, pho_high=pho_high,
                           pho_low=pho_low, p_m=p_m, fitness_p=fitness_p, learning_rate=learning_rate)
    start_time = time.time()
    DGDE_model.DGDE(x_min, x_max, objective_function, gradient_function)
    end_time = time.time()
    DGDE_model.run_time = end_time - start_time

    with open(figure_save_path + 'DGDE_model.pkl', 'wb') as f:
        joblib.dump(DGDE_model, f)

    print(f"Best Fitness: {DGDE_model.g_best.target.fitness}")
    fitness_values = [agent.target.fitness for agent in DGDE_model.pop]
    print(f"Mean Fitness: {np.mean(fitness_values)}")
    print(f"Variance of Fitness: {np.var(fitness_values)}")

    # ------------------
    print("=====Running EGD_model======")

    EGD_model = EGD.EGD(population_size=population_size, dimension=dimension, pop_strength=pop_strength,
                    mutate_strength=mutate_strength, if_escape_fitness=if_escape_fitness,
                    budget=budget, gradient_thresh=gradient_thresh, mutate_thresh=mutate_thresh,
                    learning_rate=learning_rate, mutate_turns=mutate_turns)
    start_time = time.time()
    EGD_model.EGD(x_min, x_max, objective_function, gradient_function)
    end_time = time.time()
    EGD_model.run_time = end_time - start_time

    with open(figure_save_path + 'EGD_model.pkl', 'wb') as f:
        joblib.dump(EGD_model, f)

    print(f"Best Fitness: {EGD_model.g_best.target.fitness}")
    fitness_values = [agent.target.fitness for agent in EGD_model.pop]
    print(f"Mean Fitness: {np.mean(fitness_values)}")
    print(f"Variance of Fitness: {np.var(fitness_values)}")

    # ------------------
    print("=====Running ESGD_model======")

    ESGD_model = ESGD.ESGD(population_size=population_size, mutate_strength=mutate_strength,
                      learning_rate=learning_rate, budget=budget,
                      gd_budget=gd_budget, evo_budget=evo_budget, dimension=dimension)
    start_time = time.time()
    ESGD_model.ESGD(x_min, x_max, objective_function, gradient_function)
    end_time = time.time()
    ESGD_model.run_time = end_time - start_time

    with open(figure_save_path + 'ESGD_model.pkl', 'wb') as f:
        joblib.dump(ESGD_model, f)

    print(f"Best Fitness: {ESGD_model.g_best.target.fitness}")
    fitness_values = [agent.target.fitness for agent in ESGD_model.pop]
    print(f"Mean Fitness: {np.mean(fitness_values)}")
    print(f"Variance of Fitness: {np.var(fitness_values)}")