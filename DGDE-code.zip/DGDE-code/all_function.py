import numpy as np
import os
from scipy.stats import ortho_group
from CEC2022 import *

# 全局缓存
_CACHED = {}

CEC_NAME = {
    1:"zakharov",  2:"rosenbrock",   3:"schwefel",    4:"step_rastrigin",
    5:"levy",      6:"hf02",         7:"hf10",        8:"hf06",
    9:"cf01",     10:"cf02",        11:"cf06",       12:"cf07",
    13:"zakharov",14:"rosenbrock",  15:"escaffer6",  16:"rastrigin",
    17:"levy",    18:"bent_cigar",  19:"hgbat",      20:"ellips",
    21:"katsuura",22:"happycat",    23:"grie_rosen", 24:"schwefel",
    25:"ackley",  26:"discus",      27:"griewank",   28:"schaffer_F7"
}

def generate_rotation_matrix(n):
    return ortho_group.rvs(dim=n)

def generate_shift_vector(n, low=-80, high=80):
    return np.random.uniform(low, high, n)

# def generate_rotation_matrix(n):
#     # 返回单位矩阵而不是随机正交矩阵
#     return np.eye(n)
#
# def generate_shift_vector(n, low=-80, high=80):
#     # 返回零向量而不是随机向量
#     return np.zeros(n)

def generate_shuffle_data(n):
    return np.random.permutation(n) + 1

def load_shift_and_rot(func_num: int, nx: int, data_dir: str = "input_data"):
    """
    对于复合函数：
      - 子函数总数 cf_num
      - 偏移向量长度 cf_num * nx
      - 旋转矩阵拼接后形状 (cf_num*nx, nx)
    保证 CEC2022 中的切片不越界。
    """
    os.makedirs(data_dir, exist_ok=True)
    key = (func_num, nx)
    if key in _CACHED:
        return _CACHED[key]

    cf_map = {9:5, 10:3, 11:5, 12:6}
    cf_num = cf_map.get(func_num, None)

    # 1. 偏移向量
    shift_path = os.path.join(data_dir, f"shift_data_{func_num}_D{nx}.txt")
    if os.path.exists(shift_path):
        OShift_temp = np.loadtxt(shift_path)
    else:
        length = nx if cf_num is None else cf_num * nx
        OShift_temp = generate_shift_vector(length)
        np.savetxt(shift_path, OShift_temp)

    # 2. 旋转矩阵
    M_path = os.path.join(data_dir, f"M_{func_num}_D{nx}.txt")
    if os.path.exists(M_path):
        Mr = np.loadtxt(M_path)
    else:
        if cf_num is None:
            Mr = generate_rotation_matrix(nx)
        else:
            blocks = [generate_rotation_matrix(nx) for _ in range(cf_num)]
            Mr = np.vstack(blocks)  # (cf_num*nx, nx)
        np.savetxt(M_path, Mr)

    # 3. SS
    SS = None
    if 6 <= func_num <= 8:
        shuffle_path = os.path.join(data_dir, f"shuffle_data_{func_num}_D{nx}.txt")
        if os.path.exists(shuffle_path):
            SS = np.loadtxt(shuffle_path).astype(int)
        else:
            SS = generate_shuffle_data(nx)
            np.savetxt(shuffle_path, SS, fmt='%d')

    _CACHED[key] = (OShift_temp, Mr, SS)
    return OShift_temp, Mr, SS

class ObjectiveFunction:
    """可 pickle 的目标函数封装"""
    def __init__(self, func_num, nx, Os, Mr, SS=None):
        self.func_num = func_num
        self.nx = nx
        self.Os = Os
        self.Mr = Mr
        self.SS = SS
        self.func = globals()[CEC_NAME[func_num] + "_func"]


    def __call__(self, x):
        if self.func_num == 1:
            return self.func(x, self.nx, self.Os, self.Mr, 1, 1, 1) + 300
        elif self.func_num == 2:
            return self.func(x, self.nx, self.Os, self.Mr, 1, 1, 2.048 / 100.0) + 400
        elif self.func_num == 3:
            return self.func(x, self.nx, self.Os, self.Mr, 1, 1, 1) + 600
        elif self.func_num == 4:
            return self.func(x, self.nx, self.Os, self.Mr, 1, 1, 5.12 / 100.0) + 800
        elif self.func_num == 5:
            return self.func(x, self.nx, self.Os, self.Mr,  1, 1, 1) + 900
        elif self.func_num == 6:
            return self.func(x, self.nx, self.Os, self.Mr, self.SS, 1, 1, 1) + 1800
        elif self.func_num == 7:
            return self.func(x, self.nx, self.Os, self.Mr, self.SS, 1, 1, 1) + 2000
        elif self.func_num == 8:
            return self.func(x, self.nx, self.Os, self.Mr, self.SS, 1, 1, 1) + 2200
        elif self.func_num == 9:
            return self.func(x, self.nx, self.Os, self.Mr, 1, 1, 1) + 2300
        elif self.func_num == 10:
            return self.func(x, self.nx, self.Os, self.Mr, 1, 1, 1) + 2400
        elif self.func_num == 11:
            return self.func(x, self.nx, self.Os, self.Mr, 1, 1, 1) + 2600
        elif self.func_num == 12:
            return self.func(x, self.nx, self.Os, self.Mr, 1, 1, 1) + 2700
        else:
            return self.func(x, self.nx, self.Os, self.Mr, 0, 0, 1)

class GradientFunction:
    """可 pickle 的梯度函数封装"""
    def __init__(self, func_num, nx, Os, Mr, SS=None):
        self.func_num = func_num
        self.nx = nx
        self.Os = Os
        self.Mr = Mr
        self.SS = SS
        self.grad = globals()[CEC_NAME[func_num] + "_grad"]
    def __call__(self, x):
        if self.func_num == 1:
            return self.grad(x, self.nx, self.Os, self.Mr, 1, 1, 1)
        elif self.func_num == 2:
            return self.grad(x, self.nx, self.Os, self.Mr, 1, 1, 2.048 / 100.0)
        elif self.func_num == 3:
            return self.grad(x, self.nx, self.Os, self.Mr, 1, 1, 1)
        elif self.func_num == 4:
            return self.grad(x, self.nx, self.Os, self.Mr, 1, 1, 5.12 / 100.0)
        elif self.func_num == 5:
            return self.grad(x, self.nx, self.Os, self.Mr, 1, 1, 1)
        elif self.func_num == 6:
            return self.grad(x, self.nx, self.Os, self.Mr, self.SS, 1, 1, 1)
        elif self.func_num == 7:
            return self.grad(x, self.nx, self.Os, self.Mr, self.SS, 1, 1, 1)
        elif self.func_num == 8:
            return self.grad(x, self.nx, self.Os, self.Mr, self.SS, 1, 1, 1)
        elif self.func_num == 9:
            return self.grad(x, self.nx, self.Os, self.Mr, 1, 1, 1)
        elif self.func_num == 10:
            return self.grad(x, self.nx, self.Os, self.Mr, 1, 1, 1)
        elif self.func_num == 11:
            return self.grad(x, self.nx, self.Os, self.Mr, 1, 1, 1)
        elif self.func_num == 12:
            return self.grad(x, self.nx, self.Os, self.Mr, 1, 1, 1)
        else:
            return self.grad(x, self.nx, self.Os, self.Mr, 0, 0, 1)


def select_function(func_num: int, nx: int):
    if 1 <= func_num <= 12:
        Os, Mr, SS = load_shift_and_rot(func_num, nx)
    else:
        Os = np.zeros(nx)
        Mr = np.eye(nx)
        SS = None
    f = ObjectiveFunction(func_num, nx, Os, Mr, SS)
    grad = GradientFunction(func_num, nx, Os, Mr, SS)
    return f, grad, -100, 100
