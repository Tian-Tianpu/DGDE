import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from cycler import cycler
import matplotlib.cm as cm
import os

def plot_fitness_evolution(models, figure_save_path, dpi=300):

    # colors = plt.cm.get_cmap('tab10', len(models))
    # plt.rc('axes', prop_cycle=(cycler('color', colors.colors)))
    colors_tab20b = plt.cm.get_cmap('tab20b', 20).colors
    colors_tab20c = plt.cm.get_cmap('tab20c', 20).colors

    selected_colors = [
        colors_tab20b[0], colors_tab20c[4], colors_tab20b[2],
        colors_tab20c[6], colors_tab20b[4], colors_tab20c[8],
        colors_tab20b[6], colors_tab20c[10], colors_tab20b[8],
        colors_tab20c[12], colors_tab20b[10], colors_tab20c[14],
        colors_tab20b[12]
    ]

    plt.rc('axes', prop_cycle=(cycler('color', selected_colors)))

    plt.figure(figsize=(9, 6))
    for name, model in models.items():
        legend_name = name.replace("_model", "")
        best_fitness_history = [min(ind[1] for ind in gen) for gen in model.population_history]
        plt.plot(best_fitness_history, label=legend_name)

    plt.xlabel("Generation", fontsize=18)
    plt.ylabel("Fitness", fontsize=18)
    plt.legend(fontsize=14)
    plt.savefig(figure_save_path + "best.png", dpi=dpi)
    plt.close()

    plt.figure(figsize=(9, 6))
    for name, model in models.items():
        legend_name = name.replace("_model", "")
        mean_fitness_history = [np.mean([ind[1] for ind in gen]) for gen in model.population_history]
        std_fitness_history = [np.std([ind[1] for ind in gen]) for gen in model.population_history]
        plt.plot(mean_fitness_history, label=legend_name)
        plt.fill_between(
            range(len(mean_fitness_history)),
            np.array(mean_fitness_history) - np.array(std_fitness_history),
            np.array(mean_fitness_history) + np.array(std_fitness_history),
            alpha=0.2)

    plt.xlabel("Generation", fontsize=18)
    plt.ylabel("Fitness", fontsize=18)
    plt.legend(fontsize=14)
    plt.savefig(figure_save_path + "mean.png", dpi=dpi)
    plt.close()

def plot_running_time(models, figure_save_path, dpi=300):
    """
    Args:
        models (dict): 模型字典，键为模型名称，值为模型对象。
        figure_save_path (str): 保存图像的路径。
        dpi (int): 图像分辨率。
    """

    running_times = []
    labels = []

    for name, model in models.items():
        try:
            running_time = model.run_time
            running_times.append(running_time)

            algorithm_name = name.replace("_model", "")
            labels.append(f"{algorithm_name}")

        except AttributeError:
            print(f"Model {name} does not have 'run_time' attribute.")

    colors = cm.get_cmap('tab20b', len(labels))

    plt.figure(figsize=(9, 6))
    for i, label in enumerate(labels):
        plt.bar(label, running_times[i], color=colors(i))

    plt.xlabel("Algorithm", fontsize=18)
    plt.ylabel("Running Time (seconds)", fontsize=18)
    # plt.title("Running Time of Algorithms")
    plt.xticks(rotation=45, ha="right", fontsize=14)
    plt.tight_layout()
    plt.savefig(figure_save_path + "running_time.png", dpi=dpi)
    plt.close()

def plot_Niche_num(models, figure_save_path, dpi=300):

    plt.figure(figsize=(9, 5))

    for name, model in models.items():
        if name in ["AdaptiveGDE_model", "NGDE_model"]:
            niche_history = model.niche_history
            plt.plot(niche_history, label=name.replace("_model", ""))

    plt.xlabel("Iteration", fontsize=18)
    plt.ylabel("Number of Niches", fontsize=18)
    plt.legend(fontsize=14)
    plt.savefig(figure_save_path + "niche_num.png", dpi=dpi)
    plt.close()


def result_store(figure_save_path):
    models = {}
    model_files = [
        # "GA_model.pkl",
        # "DE_model.pkl",
        # "JADE_model.pkl",
        # "SADE_model.pkl",
        # "SAP_DE_model.pkl",
        # "SHADE_model.pkl",
        # "L_SHADE_model.pkl",
        # "MPGD_model.pkl",
        "MGD_model.pkl",
        "ESGD_model.pkl",
        "EGD_model.pkl",
        "NGDE_model.pkl",
        "DGDE_model.pkl",
    ]

    for file in model_files:
        with open(figure_save_path + file, "rb") as f:
            models[file.split(".")[0]] = joblib.load(f)

    results = []
    for name, model in models.items():
        best_fitness = model.g_best.target.fitness
        fitness_values = [agent.target.fitness for agent in model.pop]
        mean_fitness = np.mean(fitness_values)
        variance_fitness = np.var(fitness_values)
        running_time = model.run_time
        try:
            niche_history = model.niche_history
        except AttributeError:
            niche_history = "N/A"

        results.append(
            {
                "Algorithm": name,
                "Best Fitness": best_fitness,
                "Mean Fitness": mean_fitness,
                "Variance Fitness": variance_fitness,
                "Running Time": running_time,
                "Niche History": niche_history
            }
        )

    df = pd.DataFrame(results)
    df.to_excel(figure_save_path + "Results.xlsx", index=False)

    plot_fitness_evolution(models, figure_save_path)

    plot_running_time(models, figure_save_path)

    plot_Niche_num(models, figure_save_path)

