import numpy as np
import pandas as pd
from gradient_based import run_gd_algorithms
from hybrids_GD_EA import run_hybrid_algorithms
from show_reults import result_store
import os
from all_function import select_function
import joblib


epoch = 10
population_size = 2
# EAs
wf = 0.5
cr = 0.5
strategy = 0
#PGD
mutate_thresh = 10
mutate_strength = 1.
gradient_thresh = 0.1
# EGD
pop_strength = 0.5
if_escape_fitness = 0.1
mutate_turns = 5
#ESGD
gd_budget = 10
evo_budget = 10
p_m = .5
#NGDE
fitness_p = 0.5
seed = 25
F = 0.5
niche_size = 5
#DGDE
K_0=1.1
K_base = 0.8
T_per = 5
pho_high = .8
pho_low = .2

Dimension = [10]


LR = [0.01]



#=================================================================
for dimension in Dimension:
    for func_name in range(1,6):
        for learning_rate in LR:
                    print("-------------Running" + str(dimension) + "D-" + str(func_name) + "-------------")

                    figure_save_path = ("./cec_1026" + "./" + str(func_name) + "/lr" + str(learning_rate) + "-K_O" + str(K_0) + "-" + str(
                                dimension) + "D/")
                    if not os.path.exists(figure_save_path):
                        os.makedirs(figure_save_path)

                    objective_function, gradient_function, x_min, x_max = select_function(func_name, dimension)

                    run_gd_algorithms(objective_function, gradient_function, x_min, x_max, figure_save_path,
                                      dimension, learning_rate, epoch, population_size, mutate_thresh,
                                      mutate_strength, gradient_thresh)

                    run_hybrid_algorithms(objective_function, gradient_function, x_min, x_max, figure_save_path,
                                          dimension, learning_rate, epoch, population_size, K_0,
                                          K_base, pho_low, pho_high, T_per, p_m,
                                           F, fitness_p, niche_size,
                                          pop_strength, mutate_strength,
                                          if_escape_fitness, gradient_thresh,
                                          mutate_thresh, mutate_turns, gd_budget, evo_budget)

                    result_store(figure_save_path)

