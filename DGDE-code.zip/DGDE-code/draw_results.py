import matplotlib.pyplot as plt
import os
import pandas as pd

def draw_results(list, function_name, dimension, figure_save_path):
    plt.figure(figsize=(8, 6))
    x0 = range(0, len(list[0]))
    x1 = range(0, len(list[1]))
    x2 = range(0, len(list[2]))
    x3 = range(0, len(list[3]))
    x4 = range(0, len(list[4]))
    x5 = range(0, len(list[5]))
    x6 = range(0, len(list[6]))
    y0 = list[0]
    y1 = list[1]
    y2 = list[2]
    y3 = list[3]
    y4 = list[4]
    y5 = list[5]
    y6 = list[6]

    plt.plot(x0, y0, color='salmon', marker='.', linestyle='-', label='MGD')
    plt.plot(x1, y1, color='cyan', marker='.', linestyle='-', label='MPGD')
    plt.plot(x2, y2, color='gold', marker='.', linestyle='-', label='DE')
    plt.plot(x3, y3, color='darkgreen', marker='.', linestyle='-', label='ESGD')
    plt.plot(x4, y4, color='royalblue', marker='.', linestyle='-', label='EGD')
    plt.plot(x5, y5, color='lightpink', marker='.', linestyle='-', label='NGDE')
    plt.plot(x6, y6, color='mediumorchid', marker='.', linestyle='-', label='ANGDE')

    plt.tick_params(labelsize=18)
    plt.xlabel('Epoches', fontsize=20)
    plt.ylabel('Function Value', fontsize=20)
    plt.legend(loc='best', fontsize=18)
    # 指定图片保存路径
    fig_name = function_name + "-" + str(dimension) + "D"
    if not os.path.exists(figure_save_path):
        os.makedirs(figure_save_path)  # 如果不存在目录figure_save_path，则创建
    plt.savefig(os.path.join(figure_save_path, fig_name), dpi=300, bbox_inches='tight')  # 分别命名图片
    plt.close()
#
#
# def draw_results(history1, function_name, dimension, figure_save_path):
#     history0 = []
#     for i in list(history1.index):
#         history0.append(list(history1.loc[i]))
#
#     plt.figure(figsize=(8, 6))
#     x0 = range(0, len(history0[0]))
#     x1 = range(0, len(history0[1]))
#     x2 = range(0, len(history0[2]))
#     x3 = range(0, len(history0[3]))
#     x4 = range(0, len(history0[4]))
#     x5 = range(0, len(history0[5]))
#     x6 = range(0, len(history0[6]))
#     y0 = history0[0]
#     y1 = history0[1]
#     y2 = history0[2]
#     y3 = history0[3]
#     y4 = history0[4]
#     y5 = history0[5]
#     y6 = history0[6]
#
#     plt.plot(x0, y0, color='salmon', marker='.', linestyle='-', label='Multi-GD')
#     plt.plot(x1, y1, color='cyan', marker='.', linestyle='-', label='Multi-PGD')
#     plt.plot(x2, y2, color='gold', marker='.', linestyle='-', label='EA')
#     plt.plot(x3, y3, color='darkgreen', marker='.', linestyle='-', label='ESGD')
#     plt.plot(x4, y4, color='royalblue', marker='.', linestyle='-', label='EGD')
#     plt.plot(x5, y5, color='lightpink', marker='.', linestyle='-', label='EA_gSBX')
#     plt.plot(x6, y6, color='mediumorchid', marker='.', linestyle='-', label='NGDE')
#
#     plt.tick_params(labelsize=18)
#
#     plt.xlabel('Epoches', fontsize=20)
#     plt.ylabel('Function Value', fontsize=20)
#     plt.legend(loc='best', fontsize=18)
#     # 指定图片保存路径
#     fig_name = function_name + "-" + str(dimension) + "D"
#     if not os.path.exists(figure_save_path):
#         os.makedirs(figure_save_path)  # 如果不存在目录figure_save_path，则创建
#     plt.savefig(os.path.join(figure_save_path, fig_name+'.png'), dpi=300, bbox_inches='tight')  # 分别命名图片
#     plt.close()
#
#
# history1 = pd.read_csv(r"./results_0109/0.1Vincent/results_best_history10D.csv",index_col=0)
# history2 = pd.read_csv(r"./results_0109/0.1Vincent/results_best_history50D.csv",index_col=0)
# history3 = pd.read_csv(r"./results_0109/0.1Vincent/results_best_history100D.csv",index_col=0)
# history4  = pd.read_csv(r"./results_0109/0.1Vincent/results_best_history200D.csv",index_col=0)
# history5  = pd.read_csv(r"./results_0109/0.1Vincent/results_best_history500D.csv",index_col=0)
# history6  = pd.read_csv(r"./results_0109/0.1Vincent/results_best_history1000D.csv",index_col=0)
# history7  = pd.read_csv(r"./results_0109/0.1Vincent/results_best_history2000D.csv",index_col=0)
# history8  = pd.read_csv(r"./results_0112/0.1Vincent/results_best_history5000D.csv",index_col=0)
# figure_save_path =  r"./function"
# function_name = "Vincent"
# dimension = "10"
# draw_results(history1, function_name, dimension, figure_save_path)
# dimension = "50"
# draw_results(history2, function_name, dimension, figure_save_path)
# dimension = "100"
# draw_results(history3, function_name, dimension, figure_save_path)
# dimension = "200"
# draw_results(history4, function_name, dimension, figure_save_path)
# dimension = "500"
# draw_results(history5, function_name, dimension, figure_save_path)
# dimension = "1000"
# draw_results(history6, function_name, dimension, figure_save_path)
# dimension = "2000"
# draw_results(history7, function_name, dimension, figure_save_path)
# dimension = "5000"
# draw_results(history8, function_name, dimension, figure_save_path)
#
#
# history1 = pd.read_csv(r"./results_0109/0.1Zakharov/results_best_history10D.csv",index_col=0)
# history2 = pd.read_csv(r"./results_0109/0.1Zakharov/results_best_history50D.csv",index_col=0)
# history3 = pd.read_csv(r"./results_0109/0.1Zakharov/results_best_history100D.csv",index_col=0)
# history4  = pd.read_csv(r"./results_0109/0.1Zakharov/results_best_history200D.csv",index_col=0)
# history5  = pd.read_csv(r"./results_0109/0.1Zakharov/results_best_history500D.csv",index_col=0)
# history6  = pd.read_csv(r"./results_0109/0.1Zakharov/results_best_history1000D.csv",index_col=0)
# history7  = pd.read_csv(r"./results_0109/0.1Zakharov/results_best_history2000D.csv",index_col=0)
# history8  = pd.read_csv(r"./results_0112/0.1Zakharov/results_best_history5000D.csv",index_col=0)
# figure_save_path =  r"./function"
# function_name = "Zakharov"
# dimension = "10"
# draw_results(history1, function_name, dimension, figure_save_path)
# dimension = "50"
# draw_results(history2, function_name, dimension, figure_save_path)
# dimension = "100"
# draw_results(history3, function_name, dimension, figure_save_path)
# dimension = "200"
# draw_results(history4, function_name, dimension, figure_save_path)
# dimension = "500"
# draw_results(history5, function_name, dimension, figure_save_path)
# dimension = "1000"
# draw_results(history6, function_name, dimension, figure_save_path)
# dimension = "2000"
# draw_results(history7, function_name, dimension, figure_save_path)
# dimension = "5000"
# draw_results(history8, function_name, dimension, figure_save_path)
#
#
# history1 = pd.read_excel(r"./results_0911/0.001Rosenbrock/results_best_history10D.xlsx",index_col=0)
# history2 = pd.read_excel(r"./results_0911/0.001Rosenbrock/results_best_history100D.xlsx",index_col=0)
# history3 = pd.read_excel(r"./results_0911/0.001Rosenbrock/results_best_history500D.xlsx",index_col=0)
# history4  = pd.read_excel(r"./results_0911/0.001Rosenbrock/results_best_history1000D.xlsx",index_col=0)
# history5  = pd.read_excel(r"./results_0911/0.001Rosenbrock/results_best_history2000D.xlsx",index_col=0)
# history6  = pd.read_excel(r"./results_0911/0.001Rosenbrock/results_best_history5000D.xlsx",index_col=0)
# history7  = pd.read_excel(r"./results_0911/0.001Rosenbrock/results_best_history10000D.xlsx",index_col=0)
# history8  = pd.read_excel(r"./results_0911/0.001Rosenbrock/results_best_history20000D.xlsx",index_col=0)
# figure_save_path =  r"./function"
# function_name = "Rosenbrock"
# dimension = "10"
# draw_results(history1, function_name, dimension, figure_save_path)
# dimension = "100"
# draw_results(history2, function_name, dimension, figure_save_path)
# dimension = "500"
# draw_results(history3, function_name, dimension, figure_save_path)
# dimension = "1000"
# draw_results(history4, function_name, dimension, figure_save_path)
# dimension = "2000"
# draw_results(history5, function_name, dimension, figure_save_path)
# dimension = "5000"
# draw_results(history6, function_name, dimension, figure_save_path)
# dimension = "10000"
# draw_results(history7, function_name, dimension, figure_save_path)
# dimension = "20000"
# draw_results(history8, function_name, dimension, figure_save_path)

# #
# # history1 = pd.read_csv(r"./results_0109/0.01Shubert/results_best_history10D.csv",index_col=0)
# # history2 = pd.read_csv(r"./results_0109/0.01Shubert/results_best_history50D.csv",index_col=0)
# # history3 = pd.read_csv(r"./results_0109/0.01Shubert/results_best_history100D.csv",index_col=0)
# # history4  = pd.read_csv(r"./results_0109/0.01Shubert/results_best_history200D.csv",index_col=0)
# # history5  = pd.read_csv(r"./results_0109/0.01Shubert/results_best_history500D.csv",index_col=0)
# # history6  = pd.read_csv(r"./results_0109/0.01Shubert/results_best_history1000D.csv",index_col=0)
# # history7  = pd.read_csv(r"./results_0109/0.01Shubert/results_best_history2000D.csv",index_col=0)
# # history8  = pd.read_csv(r"./results_0112/0.01Shubert/results_best_history5000D.csv",index_col=0)
# # figure_save_path =  r"./function"
# # function_name = "Shubert"
# # dimension = "10"
# # draw_results(history1, function_name, dimension, figure_save_path)
# # dimension = "50"
# # draw_results(history2, function_name, dimension, figure_save_path)
# # dimension = "100"
# # draw_results(history3, function_name, dimension, figure_save_path)
# # dimension = "200"
# # draw_results(history4, function_name, dimension, figure_save_path)
# # dimension = "500"
# # draw_results(history5, function_name, dimension, figure_save_path)
# # dimension = "1000"
# # draw_results(history6, function_name, dimension, figure_save_path)
# # dimension = "2000"
# # draw_results(history7, function_name, dimension, figure_save_path)
# # dimension = "5000"
# # draw_results(history8, function_name, dimension, figure_save_path)
#
# # history1 = pd.read_csv(r"./results_0109/0.001Quartic Function/results_best_history10D.csv",index_col=0)
# # history2 = pd.read_csv(r"./results_0109/0.001Quartic Function/results_best_history50D.csv",index_col=0)
# # history3 = pd.read_csv(r"./results_0109/0.001Quartic Function/results_best_history100D.csv",index_col=0)
# # history4  = pd.read_csv(r"./results_0109/0.001Quartic Function/results_best_history200D.csv",index_col=0)
# # history5  = pd.read_csv(r"./results_0109/0.001Quartic Function/results_best_history500D.csv",index_col=0)
# # history6  = pd.read_csv(r"./results_0109/0.001Quartic Function/results_best_history1000D.csv",index_col=0)
# # history7  = pd.read_csv(r"./results_0109/0.001Quartic Function/results_best_history2000D.csv",index_col=0)
# # history8  = pd.read_csv(r"./results_0109/0.001Quartic Function/results_best_history5000D.csv",index_col=0)
# # figure_save_path =  r"./function"
# # function_name = "Quartic Function"
# # dimension = "10"
# # draw_results(history1, function_name, dimension, figure_save_path)
# # dimension = "50"
# # draw_results(history2, function_name, dimension, figure_save_path)
# # dimension = "100"
# # draw_results(history3, function_name, dimension, figure_save_path)
# # dimension = "200"
# # draw_results(history4, function_name, dimension, figure_save_path)
# # dimension = "500"
# # draw_results(history5, function_name, dimension, figure_save_path)
# # dimension = "1000"
# # draw_results(history6, function_name, dimension, figure_save_path)
# # dimension = "2000"
# # draw_results(history7, function_name, dimension, figure_save_path)
# # dimension = "5000"
# # draw_results(history8, function_name, dimension, figure_save_path)
# #
# #
# # history1 = pd.read_csv(r"./results_0109/0.001Restrigin/results_best_history10D.csv",index_col=0)
# # history2 = pd.read_csv(r"./results_0109/0.001Restrigin/results_best_history50D.csv",index_col=0)
# # history3 = pd.read_csv(r"./results_0109/0.001Restrigin/results_best_history100D.csv",index_col=0)
# # history4  = pd.read_csv(r"./results_0109/0.001Restrigin/results_best_history200D.csv",index_col=0)
# # history5  = pd.read_csv(r"./results_0109/0.001Restrigin/results_best_history500D.csv",index_col=0)
# # history6  = pd.read_csv(r"./results_0109/0.001Restrigin/results_best_history1000D.csv",index_col=0)
# # history7  = pd.read_csv(r"./results_0109/0.001Restrigin/results_best_history2000D.csv",index_col=0)
# # history8  = pd.read_csv(r"./results_0109/0.001Restrigin/results_best_history5000D.csv",index_col=0)
# # figure_save_path =  r"./function"
# # function_name = "Restrigin"
# # dimension = "10"
# # draw_results(history1, function_name, dimension, figure_save_path)
# # dimension = "50"
# # draw_results(history2, function_name, dimension, figure_save_path)
# # dimension = "100"
# # draw_results(history3, function_name, dimension, figure_save_path)
# # dimension = "200"
# # draw_results(history4, function_name, dimension, figure_save_path)
# # dimension = "500"
# # draw_results(history5, function_name, dimension, figure_save_path)
# # dimension = "1000"
# # draw_results(history6, function_name, dimension, figure_save_path)
# # dimension = "2000"
# # draw_results(history7, function_name, dimension, figure_save_path)
# # dimension = "5000"
# # draw_results(history8, function_name, dimension, figure_save_path)
#
# # history1 = pd.read_csv(r"./results_0109/0.001Bent Cigar/results_best_history10D.csv",index_col=0)
# # history2 = pd.read_csv(r"./results_0109/0.001Bent Cigar/results_best_history50D.csv",index_col=0)
# # history3 = pd.read_csv(r"./results_0109/0.001Bent Cigar/results_best_history100D.csv",index_col=0)
# # history4  = pd.read_csv(r"./results_0109/0.001Bent Cigar/results_best_history200D.csv",index_col=0)
# # history5  = pd.read_csv(r"./results_0109/0.001Bent Cigar/results_best_history500D.csv",index_col=0)
# # history6  = pd.read_csv(r"./results_0109/0.001Bent Cigar/results_best_history1000D.csv",index_col=0)
# # history7  = pd.read_csv(r"./results_0109/0.001Bent Cigar/results_best_history2000D.csv",index_col=0)
# # history8  = pd.read_csv(r"./results_0109/0.001Bent Cigar/results_best_history5000D.csv",index_col=0)
# # figure_save_path =  r"./function"
# # function_name = "Bent Cigar"
# # dimension = "10"
# # draw_results(history1, function_name, dimension, figure_save_path)
# # dimension = "50"
# # draw_results(history2, function_name, dimension, figure_save_path)
# # dimension = "100"
# # draw_results(history3, function_name, dimension, figure_save_path)
# # dimension = "200"
# # draw_results(history4, function_name, dimension, figure_save_path)
# # dimension = "500"
# # draw_results(history5, function_name, dimension, figure_save_path)
# # dimension = "1000"
# # draw_results(history6, function_name, dimension, figure_save_path)
# # dimension = "2000"
# # draw_results(history7, function_name, dimension, figure_save_path)
# # dimension = "5000"
# # draw_results(history8, function_name, dimension, figure_save_path)
# #
# #
# # history1 = pd.read_csv(r"./results_0109/0.001Griewank/results_best_history10D.csv",index_col=0)
# # history2 = pd.read_csv(r"./results_0109/0.001Griewank/results_best_history50D.csv",index_col=0)
# # history3 = pd.read_csv(r"./results_0109/0.001Griewank/results_best_history100D.csv",index_col=0)
# # history4  = pd.read_csv(r"./results_0109/0.001Griewank/results_best_history200D.csv",index_col=0)
# # history5  = pd.read_csv(r"./results_0109/0.001Griewank/results_best_history500D.csv",index_col=0)
# # history6  = pd.read_csv(r"./results_0109/0.001Griewank/results_best_history1000D.csv",index_col=0)
# # history7  = pd.read_csv(r"./results_0109/0.001Griewank/results_best_history2000D.csv",index_col=0)
# # history8  = pd.read_csv(r"./results_0109/0.001Griewank/results_best_history5000D.csv",index_col=0)
# # figure_save_path =  r"./function"
# # function_name = "Griewank"
# # dimension = "10"
# # draw_results(history1, function_name, dimension, figure_save_path)
# # dimension = "50"
# # draw_results(history2, function_name, dimension, figure_save_path)
# # dimension = "100"
# # draw_results(history3, function_name, dimension, figure_save_path)
# # dimension = "200"
# # draw_results(history4, function_name, dimension, figure_save_path)
# # dimension = "500"
# # draw_results(history5, function_name, dimension, figure_save_path)
# # dimension = "1000"
# # draw_results(history6, function_name, dimension, figure_save_path)
# # dimension = "2000"
# # draw_results(history7, function_name, dimension, figure_save_path)
# # dimension = "5000"
# # draw_results(history8, function_name, dimension, figure_save_path)
#
# # history1 = pd.read_csv(r"./results_0109/0.1Ackley/results_best_history10D.csv",index_col=0)
# # history2 = pd.read_csv(r"./results_0109/0.1Ackley/results_best_history50D.csv",index_col=0)
# # history3 = pd.read_csv(r"./results_0109/0.1Ackley/results_best_history100D.csv",index_col=0)
# # history4  = pd.read_csv(r"./results_0109/0.1Ackley/results_best_history200D.csv",index_col=0)
# # history5  = pd.read_csv(r"./results_0109/0.1Ackley/results_best_history500D.csv",index_col=0)
# # history6  = pd.read_csv(r"./results_0109/0.1Ackley/results_best_history1000D.csv",index_col=0)
# # history7  = pd.read_csv(r"./results_0109/0.1Ackley/results_best_history2000D.csv",index_col=0)
# # history8  = pd.read_csv(r"./results_0112/0.1Ackley/results_best_history5000D.csv",index_col=0)
# # figure_save_path =  r"./function"
# # function_name = "Ackley"
# # dimension = "10"
# # draw_results(history1, function_name, dimension, figure_save_path)
# # dimension = "50"
# # draw_results(history2, function_name, dimension, figure_save_path)
# # dimension = "100"
# # draw_results(history3, function_name, dimension, figure_save_path)
# # dimension = "200"
# # draw_results(history4, function_name, dimension, figure_save_path)
# # dimension = "500"
# # draw_results(history5, function_name, dimension, figure_save_path)
# # dimension = "1000"
# # draw_results(history6, function_name, dimension, figure_save_path)
# # dimension = "2000"
# # draw_results(history7, function_name, dimension, figure_save_path)
# # dimension = "5000"
# # draw_results(history8, function_name, dimension, figure_save_path)
# #
# #
# # history1 = pd.read_csv(r"./results_0109/0.1Vincent/results_best_history10D.csv",index_col=0)
# # history2 = pd.read_csv(r"./results_0109/0.1Vincent/results_best_history50D.csv",index_col=0)
# # history3 = pd.read_csv(r"./results_0109/0.1Vincent/results_best_history100D.csv",index_col=0)
# # history4  = pd.read_csv(r"./results_0109/0.1Vincent/results_best_history200D.csv",index_col=0)
# # history5  = pd.read_csv(r"./results_0109/0.1Vincent/results_best_history500D.csv",index_col=0)
# # history6  = pd.read_csv(r"./results_0109/0.1Vincent/results_best_history1000D.csv",index_col=0)
# # history7  = pd.read_csv(r"./results_0109/0.1Vincent/results_best_history2000D.csv",index_col=0)
# # history8  = pd.read_csv(r"./results_0112/0.1Vincent/results_best_history5000D.csv",index_col=0)
# # figure_save_path =  r"./function"
# # function_name = "Vincent"
# # dimension = "10"
# # draw_results(history1, function_name, dimension, figure_save_path)
# # dimension = "50"
# # draw_results(history2, function_name, dimension, figure_save_path)
# # dimension = "100"
# # draw_results(history3, function_name, dimension, figure_save_path)
# # dimension = "200"
# # draw_results(history4, function_name, dimension, figure_save_path)
# # dimension = "500"
# # draw_results(history5, function_name, dimension, figure_save_path)
# # dimension = "1000"
# # draw_results(history6, function_name, dimension, figure_save_path)
# # dimension = "2000"
# # draw_results(history7, function_name, dimension, figure_save_path)
# # dimension = "5000"
# # draw_results(history8, function_name, dimension, figure_save_path)