import numpy as np
import joblib
import os
from mealpy import FloatVar
from PSO import *
import time


def run_PSOS_algorithms(objective_function, x_min, x_max, figure_save_path, dimension, epoch, pop_size,
                                c1, c2):
    """
    Args:
        function_name (str): 目标函数名称。
        dimension (int): 问题维度。
        epoch (int): 迭代次数。
        pop_size (int): 种群大小。
        wf (float): 权重因子。
        cr (float): 交叉概率。
        strategy (int): DE 策略。
        jade_pt (float): JADE pt 参数。
        jade_ap (float): JADE ap 参数。
    """

    # f_shift = np.random.uniform(-100, 100, dimension)
    # f_matrix = np.random.rand(dimension, dimension)
    # q, r = np.linalg.qr(f_matrix)
    # f_matrix = q
    # f_bias = 300.0
    #
    # objective_function, gradient_function, x_min, x_max = select_function(function_name)
    #


    problem_dict = {
        "bounds": FloatVar(lb=(int(x_min),) * int(dimension), ub=(int(x_max),) * int(dimension), name="delta"),
        "minmax": "min",
        "obj_func": objective_function
    }

    # ------------------
    print("=====Running OriginalPSO_model======")

    PSO_model = OriginalPSO(epoch=epoch, pop_size=pop_size, c1=c1, c2=c2, w=0.4)
    start_time = time.time()
    PSO_model.solve(problem_dict)
    end_time = time.time()
    PSO_model.run_time = end_time - start_time

    with open(figure_save_path + '/PSO_model.pkl', 'wb') as f:
        joblib.dump(PSO_model, f)

    print(f"Best Fitness: {PSO_model.g_best.target.fitness}")
    fitness_values = [agent.target.fitness for agent in PSO_model.pop]
    print(f"Mean Fitness: {np.mean(fitness_values)}")
    print(f"Variance of Fitness: {np.var(fitness_values)}")

    # ------------------
    print("=====Running LDW_PSO_model======")

    LDW_PSO_model = LDW_PSO(epoch=epoch, pop_size=pop_size, c1=c1, c2=c2, w_min=0.4, w_max=0.9)
    start_time = time.time()
    LDW_PSO_model.solve(problem_dict)
    end_time = time.time()
    LDW_PSO_model.run_time = end_time - start_time

    with open(figure_save_path + '/LDW_PSO_model.pkl', 'wb') as f:
        joblib.dump(LDW_PSO_model, f)

    print(f"Best Fitness: {LDW_PSO_model.g_best.target.fitness}")
    fitness_values = [agent.target.fitness for agent in LDW_PSO_model.pop]
    print(f"Mean Fitness: {np.mean(fitness_values)}")
    print(f"Variance of Fitness: {np.var(fitness_values)}")

    # ------------------
    print("=====Running P_PSO_model======")

    P_PSO_model = P_PSO(epoch=epoch, pop_size=pop_size)
    start_time = time.time()
    P_PSO_model.solve(problem_dict)
    end_time = time.time()
    P_PSO_model.run_time = end_time - start_time

    with open(figure_save_path + '/P_PSO_model.pkl', 'wb') as f:
        joblib.dump(P_PSO_model, f)

    print(f"Best Fitness: {P_PSO_model.g_best.target.fitness}")
    fitness_values = [agent.target.fitness for agent in P_PSO_model.pop]
    print(f"Mean Fitness: {np.mean(fitness_values)}")
    print(f"Variance of Fitness: {np.var(fitness_values)}")

    # ------------------
    print("=====Running HPSO_TVAC_PSO_model======")

    HPSO_TVAC_PSO_model = HPSO_TVAC(epoch=epoch, pop_size=pop_size, ci=0.5, cf=0.1)
    start_time = time.time()
    HPSO_TVAC_PSO_model.solve(problem_dict)
    end_time = time.time()
    HPSO_TVAC_PSO_model.run_time = end_time - start_time

    with open(figure_save_path + '/HPSO_TVAC_PSO_model.pkl', 'wb') as f:
        joblib.dump(HPSO_TVAC_PSO_model, f)

    print(f"Best Fitness: {HPSO_TVAC_PSO_model.g_best.target.fitness}")
    fitness_values = [agent.target.fitness for agent in HPSO_TVAC_PSO_model.pop]
    print(f"Mean Fitness: {np.mean(fitness_values)}")
    print(f"Variance of Fitness: {np.var(fitness_values)}")

    # # ------------------
    print("=====Running C_PSO_model======")

    C_PSO_model = C_PSO(epoch=epoch, pop_size=pop_size, c1=c1, c2=c2, w_min=0.4, w_max=0.9)
    start_time = time.time()
    C_PSO_model.solve(problem_dict)
    end_time = time.time()
    C_PSO_model.run_time = end_time - start_time

    with open(figure_save_path + '/C_PSO_model.pkl', 'wb') as f:
        joblib.dump(C_PSO_model, f)

    print(f"Best Fitness: {C_PSO_model.g_best.target.fitness}")
    fitness_values = [agent.target.fitness for agent in C_PSO_model.pop]
    print(f"Mean Fitness: {np.mean(fitness_values)}")
    print(f"Variance of Fitness: {np.var(fitness_values)}")

    # ------------------
    print("=====Running CL_PSO_model======")

    CL_PSO_model = CL_PSO(epoch=epoch, pop_size=pop_size, c_local=c1, w_min=0.4, w_max=0.9, max_flag=7)
    start_time = time.time()
    CL_PSO_model.solve(problem_dict)
    end_time = time.time()
    CL_PSO_model.run_time = end_time - start_time

    with open(figure_save_path + '/CL_PSO_model.pkl', 'wb') as f:
        joblib.dump(CL_PSO_model, f)

    print(f"Best Fitness: {CL_PSO_model.g_best.target.fitness}")
    fitness_values = [agent.target.fitness for agent in CL_PSO_model.pop]
    print(f"Mean Fitness: {np.mean(fitness_values)}")
    print(f"Variance of Fitness: {np.var(fitness_values)}")

